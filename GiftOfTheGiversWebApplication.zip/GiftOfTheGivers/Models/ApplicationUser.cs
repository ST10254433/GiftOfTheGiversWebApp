﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

using System;
using GiftOfTheGivers.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GiftOfTheGivers.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? RoleDescription { get; set; }

        // Navigation properties
        public ICollection<Donation>? Donations { get; set; }
        public ICollection<Incident>? Incidents { get; set; }
        public ICollection<Volunteer>? VolunteerProfiles { get; set; }
    }
}
