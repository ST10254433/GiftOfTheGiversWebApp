﻿using System;
using GiftOfTheGivers.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GiftOfTheGivers.Models
{
    public class Project
    {
        [Key]
        public int ProjectId { get; set; }

        public string Name { get; set; } = null!;

        public string? Description { get; set; }

        // Back-reference (optional)
        public ICollection<Volunteer>? Volunteers { get; set; }
    }
}
