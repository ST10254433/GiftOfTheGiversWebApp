﻿using System;
using GiftOfTheGivers.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GiftOfTheGivers.Models
{
    public class Incident
    {
        [Key]
        public int IncidentId { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; } = null!;

        [StringLength(500)]
        public string? Description { get; set; }

        [StringLength(200)]
        public string? Location { get; set; }

        public DateTime ReportedAt { get; set; } = DateTime.UtcNow;

        public string? ReportedByUserId { get; set; }  // FK to ApplicationUser.Id

        [ForeignKey(nameof(ReportedByUserId))]
        public ApplicationUser? Reporter { get; set; }
    }
}
