﻿using GiftOfTheGivers.Api.Data;
using GiftOfTheGivers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GiftOfTheGivers.Controllers
{
    [Authorize] // require login unless overridden
    public class DonationsController : Controller
    {
        private readonly ApplicationDbContext _db;
        public DonationsController(ApplicationDbContext db) => _db = db;

        // GET: /Donations
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            var donations = await _db.Donations
                .OrderByDescending(d => d.DonationDate)
                .ToListAsync();

            return View("Index", donations); // ✅ pass donations list
        }

        // GET: /Donations/Create
        // GET: /Donations/Create
        public IActionResult Create()
        {
            return View("Create");
        }

        // POST: /Donations/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Donation donation)
        {
            if (!ModelState.IsValid)
                return View("Create", donation);

            donation.DonorUserId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            donation.DonationDate = DateTime.UtcNow;

            _db.Donations.Add(donation);
            await _db.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

    }
}
